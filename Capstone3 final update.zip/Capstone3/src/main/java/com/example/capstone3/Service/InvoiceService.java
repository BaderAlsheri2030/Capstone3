package com.example.capstone3.Service;

import com.example.capstone3.ApiException.ApiException;
import com.example.capstone3.DTO.InvoiceDTO;
import com.example.capstone3.DTO.ProductDetailsDTO;
import com.example.capstone3.Model.Customer;
import com.example.capstone3.Model.Invoice;
import com.example.capstone3.Model.Product;
import com.example.capstone3.Model.ProductDetails;
import com.example.capstone3.Repository.CustomerRepository;
import com.example.capstone3.Repository.InvoiceRepository;
import com.example.capstone3.Repository.ProductDetailsRepository;
import com.example.capstone3.Repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class InvoiceService {

    private final InvoiceRepository invoiceRepository;
    private final CustomerRepository customerRepository;
    private final ProductRepository productRepository;
    private final ProductDetailsRepository productDetailsRepository;


    public List<Invoice> getInvoices(){
        return invoiceRepository.findAll();
    }


    public void addInvoice(InvoiceDTO invoiceDTO) {
        Customer customer = customerRepository.findCustomerById(invoiceDTO.getCustomer_id());
        double totalPrice = 0.0;
        double price;


        if (customer == null) {
            throw new ApiException("customer id not found");
        }

        Set<ProductDetails> s = new LinkedHashSet<>();

        for (ProductDetailsDTO p : invoiceDTO.getProductDetailsDTO()) {

            Product product = productRepository.findProductById(p.getProduct_id());

            if (product == null) {
                throw new ApiException("Invalid Product Details input");
            }

             price = product.getPrice()*p.getQuantity();
            ProductDetails productDetails = new ProductDetails(null, product, null, p.getQuantity());
            totalPrice += ((product.getSalePercentage()/100)*price)+price;

            productDetailsRepository.save(productDetails);
            s.add(productDetails);
        }

        Invoice invoice = new Invoice(null, customer, s, totalPrice, LocalDate.now(), null,null);
        invoiceRepository.save(invoice);

        for (ProductDetails p : invoice.getProductDetails()) {
            p.setInvoice(invoice);
            productDetailsRepository.save(p);
        }
    }



        public void updateInvoice (Integer id, InvoiceDTO invoice){
            Invoice invoice1 = invoiceRepository.findInvoiceById(id);
            if (invoice1 == null) {
                throw new ApiException("invalid invoice id");
            }
            invoice1.setTotalPrice(invoice.getTotalPrice());
            invoiceRepository.save(invoice1);
        }

        public void deleteInvoice (Integer id){
            Invoice invoice = invoiceRepository.findInvoiceById(id);
            if (invoice == null) {
                throw new ApiException("Invalid Invoice id");
            }
            invoiceRepository.delete(invoice);
        }



        public List<Invoice>  findInvoicesByCustomerId(Integer id){
        List<Invoice> invoices = invoiceRepository.findInvoicesByCustomerId(id);
            if (invoices.isEmpty()){
                throw new ApiException("Invalid input");
            }
            return invoices;
        }

        public List<Invoice> findInvoicesByTotalPrice(double total){
        List<Invoice> invoices = invoiceRepository.findInvoicesByTotalPriceEquals(total);
            if (invoices.isEmpty()){
                throw new ApiException("no invoices match given total price");
            }
            return invoices;
        }

    public List<Invoice> findInvoicesByTotalLessThan(double total){
        List<Invoice> invoices = invoiceRepository.findInvoicesByTotalPriceLessThanEqual(total);
        if (invoices.isEmpty()){
            throw new ApiException("no valid invoices");
        }
        return invoices;
    }

    }
