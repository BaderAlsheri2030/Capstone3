package com.example.capstone3.Service;

import com.example.capstone3.ApiException.ApiException;
import com.example.capstone3.DTO.InventoryDTO;
import com.example.capstone3.Model.Company;
import com.example.capstone3.Model.Inventory;
import com.example.capstone3.Model.Product;
import com.example.capstone3.Model.Supplier;
import com.example.capstone3.Repository.CompanyRepository;
import com.example.capstone3.Repository.InventoryRepository;
import com.example.capstone3.Repository.SupplierRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class InventoryService {
    private final InventoryRepository inventoryRepository;
    private final SupplierRepository supplierRepository;
    private final CompanyRepository companyRepository;

    public List<Inventory> getInventory(){
        return  inventoryRepository.findAll();
    }

    public void addInventory(InventoryDTO inventory){
        Set<Supplier> suppliers = new HashSet<>();
        Company company=companyRepository.findCompanyById(inventory.getCompany_id());
        if(company==null){
            throw new ApiException("Company not found");
        }

        Inventory inventory1 = new Inventory(null,null,company,null);
        inventoryRepository.save(inventory1);
    }

    //important
    public void updateInventory(Integer id, InventoryDTO inventory){
    Inventory inventory1 = inventoryRepository.findInventoryById(id);
    if (inventory1 == null){
        throw new ApiException("invalid inventory id");
    }
    inventoryRepository.save(inventory1);
    }

    public void deleteInventory(Integer id){
        Inventory inventory = inventoryRepository.findInventoryById(id);
        if (inventory == null){
            throw new ApiException("Inventory doesn't exist");
        }
    }

    public void assignSupplierToInventory(Integer supplier_id,Integer inventory_id){
        Supplier supplier = supplierRepository.findSupplierById(supplier_id);
        if(supplier == null){
            throw new ApiException("Invalid supplier id");
        }
        Inventory inventory = inventoryRepository.findInventoryById(inventory_id);
        if(inventory == null){
            throw new ApiException("Invalid Inventory id");
        }
        supplier.setInventory(inventory);
        supplierRepository.save(supplier);
    }


}
