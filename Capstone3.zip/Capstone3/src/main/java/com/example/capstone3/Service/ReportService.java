package com.example.capstone3.Service;

import com.example.capstone3.ApiException.ApiException;
import com.example.capstone3.Model.Customer;
import com.example.capstone3.Model.Employee;
import com.example.capstone3.Model.Report;
import com.example.capstone3.Repository.CustomerRepository;
import com.example.capstone3.Repository.EmployeeRepository;
import com.example.capstone3.Repository.ReportRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
@RequiredArgsConstructor
public class ReportService {
    private final ReportRepository reportRepository;
    private final CustomerRepository customerRepository;
    private final EmployeeRepository employeeRepository;

    public List<Report> getReports(){
        return reportRepository.findAll();
    }

    public void addReports(Report reports){
        reportRepository.save(reports);
    }


    public void updateReports(Integer id, Report reports){
        Report reports1=reportRepository.findReportsById(id);
        if (reports1 == null){
            throw new ApiException("Reports not found");
        }
        reportRepository.save(reports1);
    }

    public void deleteReports(Integer id){
        Report reports1=reportRepository.findReportsById(id);
        if (reports1 == null){
            throw new ApiException("Reports not found");
        }
        reportRepository.delete(reports1);
    }

    public void assignReportToCustomer(Integer report_id,Integer customer_id){
        Report report=reportRepository.findReportsById(report_id);
        Customer customer=customerRepository.findCustomerById(customer_id);
        if(report_id==null||customer==null){
            throw new ApiException("you cont complete assign");
        }
        customer.getReport().add(report);
        report.getCustomer().add(customer);
        customerRepository.save(customer);
        reportRepository.delete(report);
    }
    public void assignReportToEmployee(Integer report_id,Integer employee_id){
        Report report=reportRepository.findReportsById(report_id);
        Employee employee=employeeRepository.findEmployeeById(employee_id);
        if(report_id==null||employee==null){
            throw new ApiException("you cont complete assign");
        }
        employee.getReport().add(report);
        report.getEmployee().add(employee);
        employeeRepository.save(employee);
        reportRepository.delete(report);
    }
}
