package com.example.capstone3.Service;

import com.example.capstone3.ApiException.ApiException;
import com.example.capstone3.DTO.SupplierDTO;
import com.example.capstone3.Model.*;
import com.example.capstone3.Repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class SupplierService {
    //

    private final SupplierRepository supplierRepository;
    private final ProductRepository productRepository;
    private final ProductDetailsRepository productDetailsRepository;
    private final InventoryRepository inventoryRepository;

    public List<Supplier> getSupplier(){
        return supplierRepository.findAll();
    }

    public void addSupplier(SupplierDTO supplier){
        Inventory inventory = inventoryRepository.findInventoryById(supplier.getInventory_id());
        if(inventory==null){
            throw new ApiException("inventory not found");
        }
        Supplier supplier1 = new Supplier(null,supplier.getName(),supplier.getEmail(),supplier.getPhone(),0,inventory,null,null);
       supplierRepository.save(supplier1);
    }

    public void updateSupplier(Integer id, SupplierDTO supplier){
        Supplier supplier1 = supplierRepository.findSupplierById(id);
        if (supplier1 == null){
            throw new ApiException("Invalid supplier id");
        }

        supplier1.setEmail(supplier.getEmail());
        supplier1.setPhone(supplier.getPhone());
        supplierRepository.save(supplier1);
    }

    public void deleteSupplier(Integer id){
        Supplier supplier = supplierRepository.findSupplierById(id);
        if (supplier == null){
            throw new ApiException("invalid id");
        }
        supplierRepository.delete(supplier);
    }

    public void assignProductToSupplier(Integer supplier_id,Integer product_id){
    Supplier supplier = supplierRepository.findSupplierById(supplier_id);
    if(supplier == null){
    throw new ApiException("Invalid supplier id");
    }
        Product product = productRepository.findProductById(product_id);
        ProductDetails productDetails = productDetailsRepository.findProductDetailsByProductId(product_id);
        if (productDetails == null){
            throw new ApiException("there's no product details");
        }
        if(product == null){
            throw new ApiException("Invalid product id");
        }
        product.setSupplier(supplier);
        productRepository.save(product);
    }

}
