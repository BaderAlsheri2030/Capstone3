package com.example.capstone3.Controller;

import com.example.capstone3.DTO.ExpensesDTO;
import com.example.capstone3.Model.Expenses;
import com.example.capstone3.Service.ExpensesService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/Expenses")
public class ExpensesController {
    private final ExpensesService expensesService;

    @GetMapping("/getExpenses")
    public ResponseEntity getExpenses(){
        return ResponseEntity.status(HttpStatus.OK).body(expensesService.getExpenses());
    }
    @PostMapping("/addExpenses")
    public ResponseEntity addExpense(@RequestBody @Valid ExpensesDTO expenses){
        expensesService.addExpense(expenses);
        return ResponseEntity.status(HttpStatus.OK).body("Expenses add");
    }
    @PutMapping("update/{expense_id}")
    public ResponseEntity updateExpense(@PathVariable Integer expense_id,@Valid @RequestBody ExpensesDTO expensesDTO){
        expensesService.updateExpenses(expense_id,expensesDTO);
        return ResponseEntity.status(HttpStatus.OK).body("Expenses updated");
    }



}
