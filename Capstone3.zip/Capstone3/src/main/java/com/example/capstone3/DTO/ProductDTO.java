package com.example.capstone3.DTO;

import jakarta.persistence.Column;
import jakarta.validation.constraints.*;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class ProductDTO {
    @NotNull(message ="price should not be empty")
    private Double price;
    @NotNull(message ="sale percentage should not be empty")
    @Positive(message = "percent cannot be negative")
    @Max(value = 100,message = "invalid percentage")
    @Min(value = 1,message = "invalid percentage")
    private Integer salePercentage;
    private Integer supplier_id;
    @NotEmpty(message = " category should not be empty")
    private String category;
    @NotEmpty(message = "product name should not be empty")
    private String product_name;
}
