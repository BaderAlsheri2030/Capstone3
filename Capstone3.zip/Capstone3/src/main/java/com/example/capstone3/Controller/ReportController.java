package com.example.capstone3.Controller;

import com.example.capstone3.Model.Report;
import com.example.capstone3.Service.ReportService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/report")
@RequiredArgsConstructor
public class ReportController {
    private final ReportService reportService;

    @GetMapping("/get")
    public ResponseEntity getReports(){
        return ResponseEntity.status(200).body(reportService.getReports());
    }
    @PostMapping("/add")
    public ResponseEntity addReports(@Valid @RequestBody Report reports){
        reportService.addReports(reports);
        return ResponseEntity.status(200).body("report added");
    }

    @PutMapping("/update/{id}")
    public ResponseEntity updateReports(@PathVariable Integer id, @Valid @RequestBody Report reports){
        reportService.updateReports(id, reports);
        return ResponseEntity.status(200).body("Reports updated");
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteReports(@PathVariable Integer id){
        reportService.deleteReports(id);
        return ResponseEntity.status(200).body("Reports deleted");

    }
    @PutMapping("/assign/{report_id}/{customer_id}")
    public ResponseEntity assignReportToCustomer(@PathVariable Integer report_id,@PathVariable Integer customer_id){
        reportService.assignReportToCustomer(report_id, customer_id);
        return ResponseEntity.status(HttpStatus.OK).body("assign done");
    }
    @PutMapping("/assignEmployee/{report_id}/{employee_id}")
    public ResponseEntity assignReportToEmployee(@PathVariable Integer report_id,@PathVariable Integer employee_id){
        reportService.assignReportToEmployee(report_id, employee_id);
        return ResponseEntity.status(HttpStatus.OK).body("assign done");
    }
}
