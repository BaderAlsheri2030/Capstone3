package com.example.capstone3.Controller;

import com.example.capstone3.DTO.InvoiceDTO;
import com.example.capstone3.Model.Expenses;
import com.example.capstone3.Service.InvoiceService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/invoice")
@RequiredArgsConstructor
public class InvoiceController {

    private final InvoiceService invoiceService;


    @PostMapping("/add")
    public ResponseEntity addInvoice(@RequestBody @Valid InvoiceDTO invoiceDTO){
        invoiceService.addInvoice(invoiceDTO);
        return ResponseEntity.status(HttpStatus.OK).body("invoice created");
    }

    @GetMapping("/get")
    public ResponseEntity get(){
        return ResponseEntity.status(HttpStatus.OK).body(invoiceService.getInvoices());
    }



    @GetMapping("/customerInvoices/{customer_id}")
    public ResponseEntity getCustomerInvoices(@PathVariable Integer customer_id){
        return ResponseEntity.status(200).body(invoiceService.findInvoicesByCustomerId(customer_id));
    }

    @GetMapping("/total/equals/{total}")
    public ResponseEntity findInvoicesByTotalEquals(@PathVariable double total){
        return ResponseEntity.status(200).body(invoiceService.findInvoicesByTotalPrice(total));
    }

    @GetMapping("/total/less/{total}")
    public ResponseEntity findInvoicesByTotalLessThan(@PathVariable double total){
        return ResponseEntity.status(200).body(invoiceService.findInvoicesByTotalLessThan(total));
    }



}
