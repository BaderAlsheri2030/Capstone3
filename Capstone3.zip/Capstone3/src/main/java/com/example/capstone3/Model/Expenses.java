package com.example.capstone3.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Entity
@Setter
@Getter
public class Expenses {
    //
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(columnDefinition = "DATE")
    private LocalDate date;
    @Column
    private double salaries;
    @Column
    private double suppliers;
    @Column(columnDefinition = "double")
    private double totalExpenses;



    @OneToMany(cascade = CascadeType.ALL,mappedBy = "expenses")
    private Set<Reports> reports;


}
