package com.example.capstone3.Service;

import com.example.capstone3.ApiException.ApiException;
import com.example.capstone3.Model.Invoice;
import com.example.capstone3.Model.Sales;
import com.example.capstone3.Repository.InvoiceRepository;
import com.example.capstone3.Repository.SalesRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class SalesService {

    private final SalesRepository salesRepository;
    private final InvoiceRepository invoiceRepository;


    public List<Sales> getSales(){
        return salesRepository.findAll();
    }

    public void addSale(Sales sales){
        double totalSales = 0;
        Set<Invoice> invoices = new HashSet<>();
        for (Invoice invoice:invoiceRepository.findAll()){
                invoice.setSales(sales);
                invoices.add(invoice);
                invoiceRepository.save(invoice);
                totalSales += invoice.getTotalPrice();
        }
        if (invoices.isEmpty()){
            throw new ApiException("There is no valid invoices");
        }
        sales.setTotalSales(totalSales);
        sales.setInvoices(invoices);
        sales.setDate(sales.getDate());
        salesRepository.save(sales);
    }



    public void updateSale(Integer id,Sales sales){
        Sales sales1 = salesRepository.findSalesById(id);
        if (sales1 == null){
            throw new ApiException("invalid sales id");
        }
        sales1.setInvoices(sales.getInvoices());
        sales1.setReports(sales.getReports());
        salesRepository.save(sales1);

    }

    public void deleteSale(Integer id){
        Sales sales1 = salesRepository.findSalesById(id);
        if (sales1 == null){
            throw new ApiException("invalid id");
        }
        salesRepository.delete(sales1);
    }




}
