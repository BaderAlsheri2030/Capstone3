package com.example.capstone3.Service;

import com.example.capstone3.ApiException.ApiException;
import com.example.capstone3.DTO.SalesDTO;
import com.example.capstone3.Model.Company;
import com.example.capstone3.Model.Invoice;
import com.example.capstone3.Model.Sales;
import com.example.capstone3.Repository.CompanyRepository;
import com.example.capstone3.Repository.InvoiceRepository;
import com.example.capstone3.Repository.SalesRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class SalesService {

    private final SalesRepository salesRepository;
    private final InvoiceRepository invoiceRepository;
    private final CompanyRepository companyRepository;


    public List<Sales> getSales(){
        return salesRepository.findAll();
    }

    //add daily Invoices sales of the same,
    public void addSale(SalesDTO sales){

        Company company=companyRepository.findCompanyById(sales.getCompany_id());

        if(company==null){
            throw new ApiException("Company not found");
        }

        double totalSales = 0;
        Set<Invoice> invoices = new HashSet<>();
        for (Invoice invoice:invoiceRepository.findAll()){
            //
            if (invoice.getIssueDate().equals(LocalDate.now()) && invoice.getSales() == null) {
                    invoices.add(invoice);
                    invoiceRepository.save(invoice);
                    totalSales += invoice.getTotalPrice();
            }
        }
        if (invoices.isEmpty()){
            throw new ApiException("There is no valid invoices");
        }
        Sales sales1 = new Sales(null,sales.getDate(),null,null,company,totalSales);


        sales1.setInvoices(invoices);
        sales1.setDate(sales.getDate());
        salesRepository.save(sales1);
        for (Invoice invoice:invoiceRepository.findAll()){
            invoice.setSales(sales1);
            invoiceRepository.save(invoice);
        }


    }


    public void updateSale(Integer salesId, SalesDTO updatedSales) {
        Sales sales = salesRepository.findSalesById(salesId);

        if (sales == null) {
            throw new ApiException("Sales not found");
        }

        Company company = companyRepository.findCompanyById(updatedSales.getCompany_id());

        if (company == null) {
            throw new ApiException("Company not found");
        }

        Set<Integer> invoiceIds = new HashSet<>();


        for (Invoice invoice : sales.getInvoices()) {
                invoiceIds.add(invoice.getId());
        }


        for (Invoice invoiceId : invoiceRepository.findAll()) {
            Invoice invoice = invoiceRepository.findInvoiceById(invoiceId.getId());

            if (invoice == null) {
                throw new ApiException("Invoice not found");
            }

            if (invoiceIds.contains(invoiceId.getId())) {
                continue;
            }
            //date check
            if (!sales.getDate().equals(invoice.getIssueDate())){
                continue;
            }

            sales.getInvoices().add(invoice);
            invoice.setSales(sales);
            invoiceRepository.save(invoice);
            invoiceIds.add(invoice.getId());
        }


        // Update totalSales
        double newTotalSales = 0;
        for (Integer invoiceId : invoiceIds) {
            Invoice invoice = invoiceRepository.findInvoiceById(invoiceId);
            newTotalSales += invoice.getTotalPrice();
        }

        // Update sales with new totalSales and date
        sales.setTotalSales(newTotalSales);
        salesRepository.save(sales);
    }


    public void deleteSale(Integer id){
        Sales sales1 = salesRepository.findSalesById(id);
        if (sales1 == null){
            throw new ApiException("invalid id");
        }
        salesRepository.delete(sales1);
    }



    public List<Sales> findSalesByDate(LocalDate date){
        List<Sales> sales = salesRepository.findSalesByDateAfter(date);
        if (sales.isEmpty()){
            throw new ApiException("There is no sales for these dates");
        }
        return sales;
    }









}
