package com.example.capstone3.Model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Entity
@Setter
@Getter
public class Report {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id ;
    @NotNull(message = "report type should not be empty")
    @Column(columnDefinition = "varchar(30) not null")
    private String report_type;
    @Column(columnDefinition = "DATE")
    private LocalDate date;
    @NotNull(message = "Summary should not be empty")
    @Column(columnDefinition = "varchar(100) not null")
    private String Summary;
    @NotNull(message = "Format should not be empty")
    @Column(columnDefinition = "varchar(100) not null")
    private  String Format;
    @NotNull(message = "note should not be empty")
    @Column(columnDefinition = "varchar(250) not null")
    private String note;



    @ManyToMany(mappedBy = "report")
    private Set<Customer> customer;

    @ManyToMany(mappedBy = "report")
    private Set<Employee> employee;

    @ManyToMany(mappedBy = "report")
    private Set<Product> product;

    @ManyToMany(mappedBy = "report")
    private Set<Supplier> supplier;

    @ManyToMany(mappedBy = "report")
    private Set<Expenses> expenses;

    @ManyToMany(mappedBy = "report")
    private Set<Inventory> inventory;

    @ManyToMany(mappedBy = "report")
    private Set<Company> companies;

    @ManyToMany(mappedBy = "report")
    private Set<Invoice> invoices;

    @ManyToMany(mappedBy = "report")
    private Set<Sales> sales;

}
