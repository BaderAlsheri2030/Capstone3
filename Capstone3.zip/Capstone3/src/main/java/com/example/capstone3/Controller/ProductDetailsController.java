package com.example.capstone3.Controller;

import com.example.capstone3.DTO.ProductDetailsDTO;
import com.example.capstone3.Model.Product;
import com.example.capstone3.Service.ProductDetailsService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/productDetails")
@RequiredArgsConstructor
public class ProductDetailsController {

    private final ProductDetailsService productDetailsService;

    @GetMapping("/get")
    public ResponseEntity getProduct(){
        return ResponseEntity.status(200).body(productDetailsService.get());
    }
    @PostMapping("/add")
    public ResponseEntity addProduct(@Valid @RequestBody ProductDetailsDTO product){
        productDetailsService.addProductDetails(product);
        return ResponseEntity.status(200).body("product details added");
    }

    @PutMapping("/update/{id}")
    public ResponseEntity updateProduct(@PathVariable Integer id, @Valid @RequestBody ProductDetailsDTO product){
        productDetailsService.updateProductDetails(id,product);
        return ResponseEntity.status(200).body("product details updated");
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteProduct(@PathVariable Integer id){
        productDetailsService.deleteProductDetails(id);
        return ResponseEntity.status(200).body("product details deleted");
    }

}
