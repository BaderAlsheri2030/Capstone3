package com.example.capstone3.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Entity
@Setter
@Getter
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @NotEmpty(message = "product name should not be empty")
    @Column(columnDefinition = "varchar(100) not null")
    private String product_name;
    @NotEmpty(message = " category should not be empty")
    @Column(columnDefinition = "varchar(100) not null")
    private String category;
    @NotNull(message ="price should not be empty")
    @Column(columnDefinition = "double not null")
    private Double price;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "product")
    private Set<ProductDetails> productsDetails;
    @NotNull(message ="sale percentage should not be empty")
    @Positive(message = "percent cannot be negative")
    @Max(value = 100,message = "invalid percentage")
    @Min(value = 1,message = "invalid percentage")
    @Column(columnDefinition = "int not null")
    private Double salePercentage;



    @ManyToOne
    @JsonIgnore
    @JoinColumn(name = "supplier_id",referencedColumnName = "id")
    private Supplier supplier;

    @ManyToMany
    @JsonIgnore
    private Set<Report> report;



}
