package com.example.capstone3.Service;

import com.example.capstone3.ApiException.ApiException;
import com.example.capstone3.Model.Company;
import com.example.capstone3.Model.Expenses;
import com.example.capstone3.Model.Sales;
import com.example.capstone3.Repository.CompanyRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class CompanyService {
    private final CompanyRepository companyRepository;
    public List<Company> getCompanies(){
        return companyRepository.findAll();
    }
    public void addCompany(Company company){
        companyRepository.save(company);
    }
    public void updateCompany(Integer id, Company company){
        Company oldCompany=companyRepository.findCompanyById(id);
        if(oldCompany==null){
          throw new ApiException("Company not found");
        }
        oldCompany.setName(company.getName());
        oldCompany.setName(company.getAddress());
        oldCompany.setAddress(company.getAddress());
        oldCompany.setVatNumber(company.getVatNumber());
        companyRepository.save(oldCompany);
    }
    public void deleteCompany(Integer id){
        Company company=companyRepository.findCompanyById(id);
        if(company==null){
            throw new ApiException("Company not found");
        }
        companyRepository.delete(company);
    }

    public double calculateProfit(Integer company_id){
        double profit,s,c;
        profit=s=c = 0;

        Company company = companyRepository.findCompanyById(company_id);
        if(company==null){
            throw new ApiException("Company not found");
        }
        Set<Sales> sales= company.getSales();
        Set<Expenses> expenses = company.getExpenses();

        for (Sales sales1 :sales ){
            s += sales1.getTotalSales();
        }
        for (Expenses expenses1:expenses){
            c += expenses1.getTotalExpenses();
        }
        profit = s-c;

        return profit;
    }
}
