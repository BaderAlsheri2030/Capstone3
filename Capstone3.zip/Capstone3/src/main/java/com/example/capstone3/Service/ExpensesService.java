package com.example.capstone3.Service;

import com.example.capstone3.ApiException.ApiException;
import com.example.capstone3.DTO.ExpensesDTO;
import com.example.capstone3.Model.*;
import com.example.capstone3.Repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Repository
@RequiredArgsConstructor
public class ExpensesService {
    private final EmployeeRepository employeeRepository;
    private final SupplierRepository supplierRepository;
    private final ExpensesRepository expensesRepository;
    private final CompanyRepository companyRepository;
    private final ProductDetailsRepository productDetailsRepository;
    private final ProductRepository productRepository;

    public List<Expenses> getExpenses() {
        return expensesRepository.findAll();
    }


    public void addExpense(ExpensesDTO expensesDTO){
        Company company=companyRepository.findCompanyById(expensesDTO.getCompany_id());

        if(company==null){
            throw new ApiException("Company not found");
        }
                Calendar calendar = Calendar.getInstance();
        //this variable is not static and it depends on the day employees receive their salaries
        int dayOfSalaries = 1;
        int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
        double salaries, supCosts;
        Set<Employee> employeesSet = new HashSet<>();
        Set<Supplier> suppliers = new HashSet<>();

        salaries = supCosts = 0;

        if (dayOfMonth == dayOfSalaries) {
            for (Employee employee : employeeRepository.findAll()) {
                if (employee.getCompany().getId().equals(company.getId())) {
                    salaries += employee.getSalary();
                    employeesSet.add(employee);
                }
            }
        }

        for (Supplier supplier : supplierRepository.findAll()) {
                for (Product product:productRepository.findAll()){
                    if (checkIfProductAssignedToSupplier(supplier.getId(),product.getId())){
                        for (ProductDetails productDetails: product.getProductsDetails()){
                            supCosts += productDetails.getQuantity()*product.getPrice();
                            suppliers.add(supplier);
                        }
                    }
                }
        }
        expensesDTO.setTotalExpenses(salaries+supCosts);
        Expenses expenses = new Expenses(null,expensesDTO.getDate(),employeesSet,suppliers,expensesDTO.getTotalExpenses(),null,company);
        expensesRepository.save(expenses);
    }

    public void updateExpenses(Integer id,ExpensesDTO expensesDTO){
        Company company=companyRepository.findCompanyById(expensesDTO.getCompany_id());
        Expenses expenses = expensesRepository.findExpensesById(id);
        double salaries, supCosts;
        salaries = supCosts = 0;
        Set<Supplier> suppliers = new HashSet<>();
        Set<ProductDetails> productDetailsSet = new HashSet<>();

        if(company==null){
            throw new ApiException("Company not found");
        }
        if(expenses==null){
            throw new ApiException("expense  not found");
        }
        for (Supplier supplier : supplierRepository.findAll()) {
            for (Product product : supplier.getProduct()) {
                if (checkIfProductAssignedToSupplier(supplier.getId(), product.getId())) {
                    for (ProductDetails productDetails : product.getProductsDetails()) {
                        if (!productDetailsSet.contains(productDetails)) {
                            productDetailsSet.add(productDetails);
                            supCosts += productDetails.getQuantity() * product.getPrice();
                        }
                    }
                }
            }
        }

    }

//    public void addExpenses(Expenses expenses) {
//        Calendar calendar = Calendar.getInstance();
//        //this variable is not static and it depends on the day employees receive their salaries
//        int dayOfSalaries = 1;
//        int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
//        double salaries, supCosts;
//        salaries = supCosts = 0;
//        if (dayOfMonth == dayOfSalaries) {
//            for (Employee employee : employeeRepository.findAll()) {
//                salaries += employee.getSalary();
//            }
//        }
//        for (Supplier supplier : supplierRepository.findAll()) {
//            if (supplier.getProduct() != null) {
//                for (Product product:productRepository.findAll()) {
//                    for (ProductDetails productDetails : productDetailsRepository.findAll()) {
//                        if (product.getId().equals(productDetails.getProduct().getId())){
//                            supCosts += product.getPrice()*productDetails.getQuantity();
//                        }
//                    }
//                }
//            }
//        }
//        expenses.setTotalExpenses(salaries+supCosts);
//        expensesRepository.save(expenses);
//    }


    public boolean checkIfProductAssignedToSupplier(Integer supplier_id,Integer product_id){
        boolean isTrue = false;
        Product product = productRepository.findProductById(product_id);
        Supplier supplier = supplierRepository.findSupplierById(supplier_id);

        if (product.getSupplier().getId().equals(supplier_id)  && supplier !=null) {
            isTrue =true;
        }
        return isTrue;
    }

}
