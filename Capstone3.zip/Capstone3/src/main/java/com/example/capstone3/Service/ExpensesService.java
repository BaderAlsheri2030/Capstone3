package com.example.capstone3.Service;

import com.example.capstone3.ApiException.ApiException;
import com.example.capstone3.Model.*;
import com.example.capstone3.Repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.Calendar;
import java.util.List;

@Repository
@RequiredArgsConstructor
public class ExpensesService {
    private final EmployeeRepository employeeRepository;
    private final SupplierRepository supplierRepository;
    private final ExpensesRepository expensesRepository;
    private final ProductDetailsRepository productDetailsRepository;
    private final ProductRepository productRepository;

    public List<Expenses> getExpenses() {
        return expensesRepository.findAll();
    }

    public void addExpenses(Expenses expenses) {
        Calendar calendar = Calendar.getInstance();
        int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
        double salaries, supCosts;
        salaries = supCosts = 0;
        if (dayOfMonth == 1) {
            for (Employee employee : employeeRepository.findAll()) {
                salaries += employee.getSalary();
            }
        }
        for (Supplier supplier : supplierRepository.findAll()) {
            if (supplier.getProduct() != null) {
                for (Product product:productRepository.findAll()) {
                    for (ProductDetails productDetails : productDetailsRepository.findAll()) {
                        if (product.getId().equals(productDetails.getProduct().getId())){
                            supCosts += product.getPrice()*productDetails.getQuantity();
                        }
                    }
                }
            }
        }

        expenses.setSalaries(salaries);
        expenses.setSuppliers(supCosts);
        expenses.setTotalExpenses(salaries+supCosts);
        expensesRepository.save(expenses);
    }


}
