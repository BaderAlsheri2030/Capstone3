package com.example.capstone3.Service;

import com.example.capstone3.ApiException.ApiException;
import com.example.capstone3.Model.Inventory;
import com.example.capstone3.Model.Product;
import com.example.capstone3.Model.Supplier;
import com.example.capstone3.Repository.InventoryRepository;
import com.example.capstone3.Repository.SupplierRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class InventoryService {
    private final InventoryRepository inventoryRepository;
    private final SupplierRepository supplierRepository;

    public List<Inventory> getInventory(){
        return  inventoryRepository.findAll();
    }

    public void addInventory(Inventory inventory){
        inventoryRepository.save(inventory);
    }

    public void updateInventory(Integer id, Inventory inventory){
    Inventory inventory1 = inventoryRepository.findInventoryById(id);
    if (inventory1 == null){
        throw new ApiException("invalid inventory id");
    }
    inventory1.setSupplier(inventory.getSupplier());
    inventoryRepository.save(inventory1);
    }

    public void deleteInventory(Integer id){
        Inventory inventory = inventoryRepository.findInventoryById(id);
        if (inventory == null){
            throw new ApiException("Inventory doesn't exist");
        }
    }

    public void assignSupplierToInventory(Integer supplier_id,Integer inventory_id){
        Supplier supplier = supplierRepository.findSupplierById(supplier_id);
        if(supplier == null){
            throw new ApiException("Invalid supplier id");
        }
        Inventory inventory = inventoryRepository.findInventoryById(inventory_id);
        if(inventory == null){
            throw new ApiException("Invalid Inventory id");
        }
        supplier.setInventory(inventory);
        supplierRepository.save(supplier);
    }


}
