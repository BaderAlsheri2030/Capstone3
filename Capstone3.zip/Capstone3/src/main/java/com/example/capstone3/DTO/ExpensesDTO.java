package com.example.capstone3.DTO;

import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.time.LocalDate;

@Data
@RequiredArgsConstructor
public class ExpensesDTO {
    private Integer company_id;
    private LocalDate date;
    private double totalExpenses;
}
