package com.example.capstone3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Capstone3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
