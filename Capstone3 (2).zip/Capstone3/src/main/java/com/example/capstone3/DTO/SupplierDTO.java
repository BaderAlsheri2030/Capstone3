package com.example.capstone3.DTO;

import jakarta.persistence.Column;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class SupplierDTO {
    private double costs;
    @NotNull
    private Integer inventory_id;
    @Email(message = "Enter valid Email ")
    @NotEmpty(message = "email should not be empty")
    private String email;
    @NotEmpty(message = "First Name should not be empty")
    @Pattern(regexp = "^[a-zA-Z ]+$")
    private String name;
    @NotEmpty(message = "phone should not be empty")
    private String phone;
}
