package com.example.capstone3.Service;

import com.example.capstone3.ApiException.ApiException;
import com.example.capstone3.DTO.SupplierDTO;
import com.example.capstone3.Model.*;
import com.example.capstone3.Repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class SupplierService {
    //

    private final SupplierRepository supplierRepository;
    private final ProductRepository productRepository;
    private final ProductDetailsRepository productDetailsRepository;
    private final InventoryRepository inventoryRepository;

    public List<Supplier> getSupplier(){
        return supplierRepository.findAll();
    }

    public void addSupplier(SupplierDTO supplier){
        Inventory inventory = inventoryRepository.findInventoryById(supplier.getInventory_id());
        if(inventory==null){
            throw new ApiException("inventory not found");
        }
        Supplier supplier1 = new Supplier(null,supplier.getName(),supplier.getEmail(),supplier.getPhone(),0,inventory,null,null,null);
       supplierRepository.save(supplier1);
    }

    public void updateSupplier(Integer id, SupplierDTO supplier){
        Supplier supplier1 = supplierRepository.findSupplierById(id);
        if (supplier1 == null){
            throw new ApiException("Invalid supplier id");
        }

        supplier1.setEmail(supplier.getEmail());
        supplier1.setPhone(supplier.getPhone());
        supplierRepository.save(supplier1);
    }

    public void deleteSupplier(Integer id){
        Supplier supplier = supplierRepository.findSupplierById(id);
        if (supplier == null){
            throw new ApiException("invalid id");
        }
        supplierRepository.delete(supplier);
    }


    public void assignProductToSupplier(Integer supplierId, Integer productId) {
        double totalCost = 0;

        Supplier supplier = supplierRepository.findSupplierById(supplierId);
        if (supplier == null) {
            throw new ApiException("Invalid supplier id");
        }

        Product product = productRepository.findProductById(productId);
        if (product == null) {
            throw new ApiException("Invalid product id");
        }
        if (product.getSupplier() != null){
            throw new ApiException("There is a supplier for this product");
        }

        Set<ProductDetails> productDetailsList = productDetailsRepository.findProductDetailsByProductId(productId);
        if (productDetailsList.isEmpty()) {
            throw new ApiException("There are no product details, there must be an existent invoice");
        }

        for (ProductDetails productDetails : productDetailsList) {
            double cost = supplier.getCosts() + (product.getPrice() * productDetails.getQuantity());
            totalCost += cost;
        }

        supplier.setCosts(totalCost);
        supplierRepository.save(supplier);

        product.setSupplier(supplier);
        productRepository.save(product);
    }


    public Set<Supplier> findSuppliersByCosts(double cost){
        Set<Supplier> suppliers = supplierRepository.findSuppliersByCostsEquals(cost);

        if (suppliers.isEmpty()){
            throw new ApiException("Invalid input");
        }
        return suppliers;
    }

}
