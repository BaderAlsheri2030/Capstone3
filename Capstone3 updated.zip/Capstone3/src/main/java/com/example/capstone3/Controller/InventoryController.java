package com.example.capstone3.Controller;

import com.example.capstone3.DTO.InventoryDTO;
import com.example.capstone3.Model.Inventory;
import com.example.capstone3.Service.InventoryService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/inventory")
@RequiredArgsConstructor
public class InventoryController {

    private final InventoryService inventoryService;


    @GetMapping("/get")
    public ResponseEntity getInventory(){
       return ResponseEntity.status(200).body(inventoryService.getInventory());
    }
    @PostMapping("/add")
    public ResponseEntity addInventory(@Valid @RequestBody InventoryDTO inventory){
        inventoryService.addInventory(inventory);
        return ResponseEntity.status(200).body("Inventory added");
    }
    @PutMapping("/update/{id}")
    public ResponseEntity updateInventory(@PathVariable Integer id, @Valid @RequestBody InventoryDTO inventory){
        inventoryService.updateInventory(id,inventory);
        return ResponseEntity.status(200).body("inventory updated");
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteInventory(@PathVariable Integer id){
        inventoryService.deleteInventory(id);
        return ResponseEntity.status(200).body("inventory deleted");
    }

    @PutMapping("{inventory_id}/assign/{supplier_id}")
    public ResponseEntity assignSupplierToInventory(@PathVariable Integer inventory_id,@PathVariable Integer supplier_id){
        inventoryService.assignSupplierToInventory(supplier_id,inventory_id);
        return ResponseEntity.status(200).body("supplier assigned to inventory");


    }
}
