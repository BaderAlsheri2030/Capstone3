package com.example.capstone3.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Entity
@Setter
@Getter
public class Report {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id ;
    @Column(columnDefinition = "varchar(100)")
    private String name;


    @ManyToMany(mappedBy = "report")
    private Set<Customer> customer;

    @ManyToMany(mappedBy = "report")
    private Set<Employee> employee;

    @ManyToMany(mappedBy = "report")
    private Set<Product> product;

    @ManyToMany(mappedBy = "report")
    private Set<Supplier> supplier;

    @ManyToMany(mappedBy = "report")
    private Set<Expenses> expenses;

    @ManyToMany(mappedBy = "report")
    private Set<Inventory> inventory;

    @ManyToMany(mappedBy = "report")
    private Set<Company> companies;

    @ManyToMany(mappedBy = "report")
    private Set<Invoice> invoices;

    @ManyToMany(mappedBy = "report")
    private Set<Sales> sales;

}
